package com.zybooks.weighttracker4;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    private HomeFragment homeFragment; // Fragment for home screen
    private AlertsFragment alertsFragment; // Fragment for SMS alerts

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        homeFragment = new HomeFragment(); // Initialize HomeFragment

        // Initialize or retrieve AlertsFragment
        FragmentManager fragmentManager = getSupportFragmentManager();
        alertsFragment = (AlertsFragment) fragmentManager.findFragmentByTag("AlertsFragment");

        if (alertsFragment == null) {
            alertsFragment = new AlertsFragment(); // Create new instance if not found
            fragmentManager.beginTransaction()
                    .add(alertsFragment, "AlertsFragment")
                    .commit();
        }

        BottomNavigationView bottomNavigation = findViewById(R.id.bottom_navigation);

        // Default selected page --> Home
        bottomNavigation.setSelectedItemId(R.id.nav_home);
        loadFragment(homeFragment);

        // Handle navigation item selection
        bottomNavigation.setOnItemSelectedListener(item -> {
            if (item.getItemId() == R.id.nav_home) {
                loadFragment(homeFragment); // Load HomeFragment
                return true;
            } else if (item.getItemId() == R.id.nav_profile) {
                loadFragment(new ProfileFragment()); // Load ProfileFragment
                return true;
            } else if (item.getItemId() == R.id.nav_sms) {
                alertsFragment = new AlertsFragment(); // Create new instance to refresh UI
                loadFragment(alertsFragment);
                return true;
            } else {
                return false;
            }
        });

        // Add Button Click Listener for adding weight entry
        ImageButton addButton = findViewById(R.id.button_add);
        addButton.setOnClickListener(v -> showAddWeightDialog());
    }

    private void loadFragment(@NonNull Fragment fragment) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.frame_container, fragment);
        transaction.commit();

        // Show Add Weight button only on HomeFragment
        ImageButton addButton = findViewById(R.id.button_add);
        if (fragment instanceof HomeFragment) {
            addButton.setVisibility(View.VISIBLE);
        } else {
            addButton.setVisibility(View.GONE);
        }
    }


    private void showAddWeightDialog() {
        // Show dialog to enter weight
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_add_weight, null);
        builder.setView(dialogView);

        EditText weightInput = dialogView.findViewById(R.id.get_weight);
        Button submitButton = dialogView.findViewById(R.id.btn_submit_weight);

        AlertDialog dialog = builder.create();

        submitButton.setOnClickListener(v -> {
            String weight = weightInput.getText().toString();
            if (!weight.isEmpty()) {
                homeFragment.addEntry(weight); // Add entry to HomeFragment list
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    public AlertsFragment getAlertsFragment() {
        // Retrieve or create AlertsFragment instance
        AlertsFragment fragment = (AlertsFragment) getSupportFragmentManager().findFragmentByTag("AlertsFragment");
        if (fragment == null) {
            fragment = new AlertsFragment();
            getSupportFragmentManager().beginTransaction()
                    .add(fragment, "AlertsFragment")
                    .commit();
        }
        return fragment;
    }
}
