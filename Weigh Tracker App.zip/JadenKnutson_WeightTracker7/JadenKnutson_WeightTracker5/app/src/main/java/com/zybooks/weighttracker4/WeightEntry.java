package com.zybooks.weighttracker4;

public class WeightEntry {
    private final int id; // Unique identifier for weight entry
    private final String weight; // Weight value as string
    private final String date; // Date of weight entry

    // Constructor to initialize a WeightEntry object
    public WeightEntry(int id, String weight, String date) {
        this.id = id;
        this.weight = weight;
        this.date = date;
    }

    // Getter method to retrieve entry ID
    public int getId() {
        return id;
    }

    // Getter method to retrieve weight value
    public String getWeight() {
        return weight;
    }

    // Getter method to retrieve date of entry
    public String getDate() {
        return date;
    }
}
