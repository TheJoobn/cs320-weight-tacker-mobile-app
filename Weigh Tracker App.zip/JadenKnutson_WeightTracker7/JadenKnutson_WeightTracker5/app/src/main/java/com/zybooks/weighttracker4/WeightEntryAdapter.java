package com.zybooks.weighttracker4;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class WeightEntryAdapter extends RecyclerView.Adapter<WeightEntryAdapter.WeightEntryViewHolder> {

    private final Context context; // Application context
    private final List<WeightEntry> weightEntries; // List of weight entries to display
    private final OnEntryClickListener listener; // Listener for edit and delete actions

    // Interface for handling edit and delete actions
    public interface OnEntryClickListener {
        void onEditClick(WeightEntry entry);
        void onDeleteClick(WeightEntry entry);
    }

    // Constructor to initialize adapter with context, data, and listener
    public WeightEntryAdapter(Context context, List<WeightEntry> weightEntries, OnEntryClickListener listener) {
        this.context = context;
        this.weightEntries = weightEntries;
        this.listener = listener;
    }

    @NonNull
    @Override
    public WeightEntryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate item layout for each entry
        View view = LayoutInflater.from(context).inflate(R.layout.item_weight_entry, parent, false);
        return new WeightEntryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WeightEntryViewHolder holder, int position) {
        // Get weight entry at current position
        WeightEntry entry = weightEntries.get(position);

        // Set weight and date values to TextViews
        holder.weightTextView.setText(entry.getWeight());
        holder.dateTextView.setText(entry.getDate());

        // Set click listeners for edit and delete buttons
        holder.editButton.setOnClickListener(v -> listener.onEditClick(entry));
        holder.deleteButton.setOnClickListener(v -> listener.onDeleteClick(entry));
    }

    @Override
    public int getItemCount() {
        return weightEntries.size(); // Return number of weight entries
    }

    // ViewHolder class for holding item view elements
    public static class WeightEntryViewHolder extends RecyclerView.ViewHolder {
        TextView weightTextView, dateTextView; // TextViews for displaying weight and date
        Button editButton, deleteButton; // Buttons for editing and deleting entries

        public WeightEntryViewHolder(@NonNull View itemView) {
            super(itemView);
            weightTextView = itemView.findViewById(R.id.weight_text);
            dateTextView = itemView.findViewById(R.id.date_text);
            editButton = itemView.findViewById(R.id.edit_button);
            deleteButton = itemView.findViewById(R.id.delete_button);
        }
    }
}
