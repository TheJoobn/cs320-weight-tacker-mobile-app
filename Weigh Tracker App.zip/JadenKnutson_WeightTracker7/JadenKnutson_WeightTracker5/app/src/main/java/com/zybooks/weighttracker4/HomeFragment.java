package com.zybooks.weighttracker4;

import android.app.AlertDialog;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment implements WeightEntryAdapter.OnEntryClickListener {

    private WeightEntryAdapter weightEntryAdapter;
    private DatabaseHelper databaseHelper;
    private AlertsFragment alertsFragment;
    private List<WeightEntry> weightEntries;
    private boolean goalReached;

    public HomeFragment() {}

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // Initialize RecyclerView for displaying weight entries
        RecyclerView recyclerView = view.findViewById(R.id.recycler_view_entries);
        recyclerView.setLayoutManager(new LinearLayoutManager(requireActivity()));

        // Initialize database helper
        databaseHelper = new DatabaseHelper(requireContext());
        weightEntries = new ArrayList<>();

        // Set up adapter for RecyclerView
        weightEntryAdapter = new WeightEntryAdapter(requireActivity(), weightEntries, this);
        recyclerView.setAdapter(weightEntryAdapter);

        // Get reference to AlertsFragment
        alertsFragment = ((MainActivity) requireActivity()).getAlertsFragment();

        loadEntries(); // Load user data
        return view;
    }

    // Load Weight Entries
    private void loadEntries() {
        weightEntries.clear();
        String username = getLoggedInUsername();
        Cursor cursor = databaseHelper.getUserEntries(username);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                int id = cursor.getInt(0);
                String date = cursor.getString(2);
                String weight = cursor.getString(3);

                Log.d("Database Debug", "ID: " + id + " | Weight: " + weight + " | Date: " + date);
                weightEntries.add(new WeightEntry(id, weight, date));
            }
            cursor.close();
        }
        weightEntryAdapter.notifyDataSetChanged();
    }

    // Adds to the weight entries
    public void addEntry(String weight) {
        String username = getLoggedInUsername();
        if (databaseHelper.addWeightEntry(username, weight)) {
            Log.d("Database Debug", "Added entry for: " + username + " Weight: " + weight);
            loadEntries();
            checkGoalAndSendSMS(username, weight);
        }
    }

    // Retrieve Logged in username
    private String getLoggedInUsername() {
        return requireActivity().getSharedPreferences("UserSession", Context.MODE_PRIVATE)
                .getString("username", "");
    }

    // Edit Entry
    @Override
    public void onEditClick(WeightEntry entry) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Edit Weight Entry");

        final EditText input = new EditText(getActivity());
        input.setText(entry.getWeight());
        builder.setView(input);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String newWeight = input.getText().toString().trim();
            if (!newWeight.isEmpty()) {
                databaseHelper.updateWeightEntry(entry.getId(), newWeight);
                loadEntries();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        builder.show();
    }

    // Delete Entry
    @Override
    public void onDeleteClick(WeightEntry entry) {
        databaseHelper.deleteEntry(entry.getId());
        loadEntries();
    }

    // Check goal, validate, send sms
    private void checkGoalAndSendSMS(String username, String weight) {
        if (username == null || username.isEmpty()) return;

        String[] weights = databaseHelper.getUserWeights(username);
        String goalWeightStr = weights[1];

        if (goalWeightStr != null && !goalWeightStr.isEmpty()) {
            try {
                float userWeight = Float.parseFloat(weight);
                float goalWeight = Float.parseFloat(goalWeightStr);

                if (userWeight == goalWeight && !goalReached) {
                    goalReached = true;
                    if (alertsFragment != null && alertsFragment.isAdded() && alertsFragment.isSmsEnabled()) {
                        if (alertsFragment.hasSmsPermission(requireContext())) {
                            alertsFragment.sendSmsAlert(requireContext(), "+1234567890",
                                    "Congratulations! You've reached your goal weight!");
                            Toast.makeText(getActivity(), "Goal reached! SMS sent.", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(getActivity(), "SMS Permission required", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            } catch (NumberFormatException e) {
                Log.e("GoalCheck", "Error parsing weight", e);
            }
        }
    }

    private float lastCheckedGoalWeight = -1;

    // Refresh the goal Check for SMS
    public void refreshGoalCheck() {
        String username = getLoggedInUsername();
        if (!weightEntries.isEmpty()) {
            String latestWeight = weightEntries.get(0).getWeight();
            float userWeight = Float.parseFloat(latestWeight);
            String[] weights = databaseHelper.getUserWeights(username);
            float goalWeight = Float.parseFloat(weights[1]);

            if (!goalReached && userWeight <= goalWeight) {
                if (lastCheckedGoalWeight != goalWeight) {
                    lastCheckedGoalWeight = goalWeight;
                } else {
                    checkGoalAndSendSMS(username, latestWeight);
                }
            }
        }
    }

    public void resetGoalNotification() {
        goalReached = false;
        lastCheckedGoalWeight = -1;
    }
}
