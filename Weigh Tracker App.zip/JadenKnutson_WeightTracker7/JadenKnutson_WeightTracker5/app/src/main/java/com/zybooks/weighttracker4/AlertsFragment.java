package com.zybooks.weighttracker4;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ToggleButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

public class AlertsFragment extends Fragment {

    private static final int SMS_PERMISSION_CODE = 101; // Request code for SMS permission
    private ToggleButton toggleAlerts; // Toggle button to enable/disable SMS alerts
    private boolean isSmsEnabled = false; // Tracks if SMS alerts are enabled
    private SharedPreferences sharedPreferences; // SharedPreferences to store user settings

    public AlertsFragment() {
        // Empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the fragment layout
        View view = inflater.inflate(R.layout.fragment_alerts, container, false);

        // Initialize UI components
        Button buttonRequestSms = view.findViewById(R.id.button_request_sms);
        // Buttons for requesting and sending SMS
        Button buttonSendSms = view.findViewById(R.id.button_send_sms);
        toggleAlerts = view.findViewById(R.id.toggle_alerts);

        // Retrieve shared preferences for storing SMS alert state
        sharedPreferences = requireContext().getSharedPreferences("prefs", Context.MODE_PRIVATE);

        // Load saved SMS permission state when fragment starts
        loadSmsPermissionState();

        // Set up button click listeners
        buttonRequestSms.setOnClickListener(v -> requestSmsPermission()); // Request SMS permission
        buttonSendSms.setOnClickListener(v -> {
            if (isSmsEnabled) {
                // Send test SMS if alerts enabled
                sendSmsAlert(requireContext(), "+1234567890", "Test SMS from WeightTracker");
            } else {
                Toast.makeText(requireContext(), "SMS alerts are turned off", Toast.LENGTH_SHORT).show();
            }
        });

        // Toggle SMS alert state when user interacts with toggle button
        toggleAlerts.setOnCheckedChangeListener((buttonView, isChecked) -> {
            isSmsEnabled = isChecked;
            saveSmsPermissionState(isSmsEnabled); // Save state
            loadSmsPermissionState(); // Reload state
        });

        return view;
    }

    private void loadSmsPermissionState() {
        // Retrieve logged-in username to store user preferences
        String username = getLoggedInUsername();
        boolean smsPermissionGranted = sharedPreferences.getBoolean(username + "_smsEnabled", false);

        // Check if SMS permission granted
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            toggleAlerts.setChecked(smsPermissionGranted);
            isSmsEnabled = smsPermissionGranted;
            toggleAlerts.setEnabled(true); // Enable toggle if permission granted
        } else {
            toggleAlerts.setChecked(false);
            isSmsEnabled = false;
            toggleAlerts.setEnabled(false); // Disable toggle if permission not granted
        }
    }

    private void saveSmsPermissionState(boolean state) {
        // Save SMS alert state for logged-in user
        String username = getLoggedInUsername();
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(username + "_smsEnabled", state);
        editor.apply(); // Apply changes
    }

    private void requestSmsPermission() {
        // Request SMS permission if not already granted
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(requireActivity(), new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        } else {
            // Notify user that permission is already granted or toggles the off/on button to on
            Toast.makeText(requireContext(), "SMS Permission already granted", Toast.LENGTH_SHORT).show();
            toggleAlerts.setChecked(true);
            isSmsEnabled = true;
            toggleAlerts.setEnabled(true);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, enable SMS alerts
                Toast.makeText(requireContext(), "SMS Permission granted", Toast.LENGTH_SHORT).show();
                toggleAlerts.setChecked(true);
                isSmsEnabled = true;
                toggleAlerts.setEnabled(true);
            } else {
                // Permission denied, disable SMS alerts
                Toast.makeText(requireContext(), "SMS Permission denied", Toast.LENGTH_SHORT).show();
                toggleAlerts.setChecked(false);
                isSmsEnabled = false;
                toggleAlerts.setEnabled(false);
            }
        }
    }

    public void sendSmsAlert(Context context, String phoneNumber, String message) {
        // Check for valid context, SMS permission is granted, and alerts are enabled
        if (context != null && hasSmsPermission(context) && isSmsEnabled()) {
            try {
                // Send SMS using SmsManager
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                Toast.makeText(context, "Test SMS Sent", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                // Handle SMS failure
                Toast.makeText(context, "SMS failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        } else {
            // Notify user if SMS sending is blocked due to permission or setting
            Toast.makeText(context, "SMS Permission required or alerts are off", Toast.LENGTH_SHORT).show();
        }
    }

    public boolean isSmsEnabled() {
        // Check if SMS alerts are enabled for logged-in user
        String username = getLoggedInUsername();
        return sharedPreferences.getBoolean(username + "_smsEnabled", false);
    }

    public boolean hasSmsPermission(Context context) {
        // Check if app has SMS sending permission
        return ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    private String getLoggedInUsername() {
        // Retrieve currently logged-in username from SharedPreferences
        SharedPreferences sharedPreferences = requireContext().getSharedPreferences("UserSession", Context.MODE_PRIVATE);
        return sharedPreferences.getString("username", "");
    }
}
