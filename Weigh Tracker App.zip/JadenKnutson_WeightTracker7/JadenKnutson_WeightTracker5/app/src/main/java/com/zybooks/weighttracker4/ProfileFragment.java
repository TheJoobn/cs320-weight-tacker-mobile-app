package com.zybooks.weighttracker4;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

public class ProfileFragment extends Fragment {

    private EditText startingWeightInput, goalWeightInput; // Input fields for user weights
    private DatabaseHelper databaseHelper; // Handles database operations

    public ProfileFragment() {
        // Empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate layout for fragment
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        // Reference UI elements
        Button loginButton = view.findViewById(R.id.button);
        // Displays logged-in username
        TextView usernameTextView = view.findViewById(R.id.usernameTextView);
        startingWeightInput = view.findViewById(R.id.editTextStartWeight);
        goalWeightInput = view.findViewById(R.id.editTextGoalWeight);

        // Initialize shared preferences and database helper
        // Stores user session data
        SharedPreferences sharedPreferences = requireActivity().getSharedPreferences("UserSession", Context.MODE_PRIVATE);
        databaseHelper = new DatabaseHelper(getActivity());

        // Retrieve logged-in username from shared preferences
        String username = sharedPreferences.getString("username", null);

        if (username != null) {
            usernameTextView.setText(username); // Display username
            loadUserWeights(username); // Load user's saved weights
        } else {
            usernameTextView.setText("User Not Logged In"); // Show message if no user is logged in
        }

        // Save weight data when user input loses focus
        startingWeightInput.setOnFocusChangeListener((v, hasFocus) -> {
            if (!hasFocus) saveUserWeights(username);
        });

        goalWeightInput.setOnFocusChangeListener((v, hasFocus) -> {
            if (!hasFocus) saveUserWeights(username);
        });

        // Set click listener for Login Button
        loginButton.setOnClickListener(v -> {
            // Navigate to LoginFragment when login button is clicked
            Fragment loginFragment = new LoginFragment();
            FragmentTransaction transaction = getParentFragmentManager().beginTransaction();
            transaction.replace(R.id.frame_container, loginFragment);
            transaction.addToBackStack(null);
            transaction.commit();
        });

        return view;
    }

    private void loadUserWeights(String username) {
        // Load stored weight data for logged-in user
        if (username != null) {
            String[] weights = databaseHelper.getUserWeights(username);
            startingWeightInput.setText(weights[0]); // Set starting weight
            goalWeightInput.setText(weights[1]); // Set goal weight
        }
    }

    private void saveUserWeights(String username) {
        if (username != null) {
            String startingWeight = startingWeightInput.getText().toString();
            String goalWeight = goalWeightInput.getText().toString();
            databaseHelper.updateUserWeights(username, startingWeight, goalWeight);

            // 🔹 Notify HomeFragment to refresh the goal check and reset notification flag
            Fragment homeFragment = getParentFragmentManager().findFragmentById(R.id.frame_container);
            if (homeFragment instanceof HomeFragment) {
                ((HomeFragment) homeFragment).resetGoalNotification(); // Reset goal reached flag
                ((HomeFragment) homeFragment).refreshGoalCheck(); // Re-evaluate goal immediately
            }
        }
    }


}
