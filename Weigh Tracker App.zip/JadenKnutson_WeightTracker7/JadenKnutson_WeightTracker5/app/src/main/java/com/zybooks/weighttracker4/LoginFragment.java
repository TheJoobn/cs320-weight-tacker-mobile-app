package com.zybooks.weighttracker4;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

public class LoginFragment extends Fragment {

    private DatabaseHelper databaseHelper; // Handles database operations
    private EditText usernameInput, passwordInput; // User input fields

    public LoginFragment() {
        // Empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate layout for fragment
        View view = inflater.inflate(R.layout.fragment_login, container, false);

        // Initialize database helper
        databaseHelper = new DatabaseHelper(getActivity());

        // Find views by their IDs
        usernameInput = view.findViewById(R.id.username);
        passwordInput = view.findViewById(R.id.password);
        Button loginButton = view.findViewById(R.id.btnLoginSubmit);
        // Buttons for login and registration
        Button registerButton = view.findViewById(R.id.btnLoginSubmit2);

        // Set click listeners for login and register buttons
        loginButton.setOnClickListener(v -> handleLogin());
        registerButton.setOnClickListener(v -> handleRegister());

        return view;
    }

    private void handleLogin() {
        // Retrieve and trim input values
        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();

        // Check if fields are empty
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(getActivity(), "Please enter both username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validate user credentials
        if (databaseHelper.validateUser(username, password)) {
            clearHomeScreenData(); // Ensure home screen refreshes when switching users
            saveUserSession(username); // Store session data
            Toast.makeText(getActivity(), "Login successful!", Toast.LENGTH_SHORT).show();
            navigateToHome(); // Redirect to home screen
        } else {
            Toast.makeText(getActivity(), "Invalid credentials", Toast.LENGTH_SHORT).show();
        }
    }

    private void handleRegister() {
        // Retrieve and trim input values
        String username = usernameInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();

        // Check if fields empty
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(getActivity(), "Please enter both username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        // Attempt to register user
        if (databaseHelper.registerUser(username, password)) {
            clearHomeScreenData(); // Ensure home screen refreshes for new users
            saveUserSession(username); // Store session data
            Toast.makeText(getActivity(), "Registration successful!", Toast.LENGTH_SHORT).show();
            navigateToHome(); // Redirect to home screen
        } else {
            Toast.makeText(getActivity(), "Username already exists", Toast.LENGTH_SHORT).show();
        }
    }

    private void saveUserSession(String username) {
        // Store username in shared preferences
        SharedPreferences sharedPreferences = requireActivity().getSharedPreferences("UserSession", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("username", username);
        editor.apply(); // Apply changes
    }

    private void clearHomeScreenData() {
        // Clear cached home screen data
        SharedPreferences sharedPreferences = requireActivity().getSharedPreferences("UserSession", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove("home_screen_data"); // Remove cached data
        editor.apply();
    }

    private void navigateToHome() {
        // Start MainActivity and finish current activity
        Intent intent = new Intent(getActivity(), MainActivity.class);
        startActivity(intent);
        requireActivity().finish();
    }
}
